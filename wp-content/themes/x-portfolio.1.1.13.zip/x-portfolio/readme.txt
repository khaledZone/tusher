
== X-Portfolio
Contributors: Afrothemes
Tags: two-columns, left-sidebar, custom-colors, custom-menu, custom-logo, featured-images, threaded-comments, translation-ready, blog, portfolio, photogprahy
Requires at least: 4.5
Requires PHP: 5.2.4
Tested up to: 5.2
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html  


== Description ==

A Minimal WordPress portfolio theme for designers, photographers and illustrators 
 



== Frequently Asked Questions ==

 = Can I create portfolio posts types =
 
You will need the pro plugin, it costs $39

 = Can I get Support =

Dedicated email support is available for premium users, if you are using the free theme, leave your comment on the forums and a volunteer might get back to you


==  Copyright ==



X Portfolio bundles the following third-party resources:

  Simple Grid
  Project Page - http://thisisdallas.github.com/Simple-Grid/
  Author - Dallas Bass
  Site - http://dallasbass.com

screenshots:
All from pixabay 
licence: https://pixabay.com/en/service/terms/#usage

https://pixabay.com/en/dental-care-dental-mascot-teeth-2516133/
https://pixabay.com/en/man-mirror-tooth-blue-bathroom-2166254/
https://pixabay.com/en/bird-beak-charming-eyes-looking-1773631/
https://pixabay.com/en/teeth-cartoon-hygiene-cleaning-1670434/
https://pixabay.com/en/bow-tux-inkscape-vector-penguin-1625964/
https://pixabay.com/en/pumpkin-halloween-cartoon-1640465/
https://pixabay.com/en/female-woman-girl-zombie-undead-1781412/
https://pixabay.com/en/zombie-brain-halloween-dead-521243/

## Changelog
### 1.1.12
* Fixed responsive issues

### 1.0
* Released: june 10, 2017

Initial release